﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace proyecto_de_CineGT
{
    public partial class FormVentaAsientos : Form
    {
        private SqlConnection conn;
        private string nombreUsuarioActivo;
        private string rolUsuario;
        private string nombreUsuario;
        public FormVentaAsientos(string nombreUsuario)
        {
            this.nombreUsuario = nombreUsuario;
            InitializeComponent();
            InitializeConnection();
            InitializeDataGridView();
            conn = GetConnection(); // Método para obtener la conexión a la base de datos
            LoadComboBoxSesiones(); // Cargar sesiones en el ComboBox
            LoadSesiones();
            LoadTransacciones();
            LoadAsientoTransaccion();
        }

        private void InitializeDataGridView()
        {
            // Definir las columnas
            dataGridViewAsientos.Columns.Clear();
            dataGridViewAsientos.Columns.Add("Asiento", "Asiento Seleccionado");

            // Configurar el DataGridView para AsientoTransaccion (dataGridViewTransacciones)
            dataGridViewTransacciones.Columns.Clear();
            dataGridViewTransacciones.Columns.Add("Transaccion", "Transacción Seleccionada");
        }



        private void LoadComboBoxSesiones()
        {
            string query = "SELECT s.id_sesion, s.id_sala, CONCAT('Película: ', p.nombre, ' - Sala: ', sa.nombre_sala, ' - Fecha: ', FORMAT(s.fecha_hora_inicio, 'g')) AS descripcion " +
               "FROM Sesion s " +
               "JOIN Pelicula p ON s.id_pelicula = p.id_pelicula " +
               "JOIN Sala sa ON s.id_sala = sa.id_sala " +
               "WHERE s.estado = 'activa'";

            using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
            {
                DataTable table = new DataTable();
                try
                {
                    conn.Open();
                    adapter.Fill(table);
                    cmbSesiones.DataSource = table;
                    cmbSesiones.DisplayMember = "descripcion";
                    cmbSesiones.ValueMember = "id_sesion";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar las sesiones: {ex.Message}");
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        private void LoadSesiones()
        {
            string query = @"
        SELECT 
            s.id_sesion, 
            sa.id_sala, 
            p.nombre AS pelicula_nombre, 
            sa.nombre_sala AS sala_nombre, 
            s.fecha_hora_inicio 
        FROM Sesion s 
        JOIN Sala sa ON s.id_sala = sa.id_sala 
        JOIN Pelicula p ON s.id_pelicula = p.id_pelicula";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                try
                {
                    conn.Open(); // Abre la conexión aquí
                    adapter.Fill(table);
                    cmbSesiones.DataSource = table;

                    // Establecer la visualización del ComboBox
                    cmbSesiones.DisplayMember = "pelicula_nombre"; // Mostrar nombre de la película
                    cmbSesiones.ValueMember = "id_sesion"; // Usar ID de la sesión

                    // Opcional: Modificar la forma en que se visualizan los elementos
                    foreach (DataRow row in table.Rows)
                    {
                        row["pelicula_nombre"] = $"{row["pelicula_nombre"]} - Sala: {row["sala_nombre"]} - Fecha y Hora: {((DateTime)row["fecha_hora_inicio"]).ToString("g")}";
                    }
                    cmbSesiones.DisplayMember = "pelicula_nombre"; // Volver a establecer después de modificar
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar las sesiones: {ex.Message}");
                }
                finally
                {
                    conn.Close(); // Asegúrate de cerrar la conexión
                }
            }
        }


        private void LoadTransacciones()
        {
            string query = @"
                SELECT 
                    T.id_transaccion, 
                    T.id_sesion, 
                    T.id_sala, 
                    T.fila, 
                    T.numero, T.id_asiento
                FROM Transaccion T
                JOIN Sesion S ON T.id_sesion = S.id_sesion
                ORDER BY T.id_transaccion DESC";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                try
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    adapter.Fill(table);
                    dataGridViewAsientos.DataSource = table;

                    // Ajustar encabezados si es necesario
                    dataGridViewAsientos.Columns["id_transaccion"].HeaderText = "ID Transacción";
                    dataGridViewAsientos.Columns["id_sesion"].HeaderText = "ID Sesión";
                    dataGridViewAsientos.Columns["id_sala"].HeaderText = "ID Sala";
                    dataGridViewAsientos.Columns["fila"].HeaderText = "Fila";
                    dataGridViewAsientos.Columns["numero"].HeaderText = "Número";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar los datos de transacciones: {ex.Message}");
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void LoadAsientoTransaccion()
        {
            string query = @"
    SELECT 
        at.id_transaccion,
        at.id_usuario,
        at.id_sesion,
        at.fecha_hora,
        at.total_asientos,
        at.tipo_asignacion
    FROM AsientoTransaccion at
    ORDER BY at.id_transaccion DESC";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                try
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    adapter.Fill(table);
                    dataGridViewTransacciones.DataSource = table;

                    // Ajustar encabezados si es necesario
                    dataGridViewTransacciones.Columns["id_transaccion"].HeaderText = "ID Transacción";
                    dataGridViewTransacciones.Columns["id_usuario"].HeaderText = "ID Usuario";
                    dataGridViewTransacciones.Columns["id_sesion"].HeaderText = "ID Sesión";
                    dataGridViewTransacciones.Columns["fecha_hora"].HeaderText = "Fecha y Hora";
                    dataGridViewTransacciones.Columns["total_asientos"].HeaderText = "Total Asientos";
                    dataGridViewTransacciones.Columns["tipo_asignacion"].HeaderText = "Tipo de Asignación";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al cargar los datos de AsientoTransaccion: {ex.Message}");
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        private SqlConnection GetConnection()
        {
            return new SqlConnection(ConfigurationManager.ConnectionStrings["CineDB"].ConnectionString);
        }

        private void InitializeConnection()
        {
            conn = GetConnection(); // Inicializa la conexión
            if (conn == null)
            {
                MessageBox.Show("Error al establecer la conexión con la base de datos.");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            var selectedSession = (DataRowView)cmbSesiones.SelectedItem;
            int idSesion = (int)selectedSession["id_sesion"];
            int idSala = (int)selectedSession["id_sala"];
            int cantidadAsientos = (int)numericUpDownCantidadAsientos.Value;

            if (radioButtonAutomatico.Checked)
            {
                AsignarAsientosAutomatica(idSesion, idSala, cantidadAsientos);
            }
            else if (radioButtonManual.Checked)
            {
                AsignarAsientosManual(idSesion, idSala, cantidadAsientos);
            }
            else
            {
                MessageBox.Show("Seleccione un método de asignación.");
            }

            // Recargar ambas tablas para reflejar la compra
            LoadTransacciones();
            LoadAsientoTransaccion();
        }

        //AgregarTransaccion


        private int ObtenerIdUsuario()
        {
            string query = "SELECT rol FROM Usuario WHERE nombre_usuario = @nombreUsuario";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@nombreUsuario", nombreUsuario);
                try
                {
                    conn.Open();
                    var rol = cmd.ExecuteScalar() as string;
                    conn.Close();

                    if (rol == "admin")
                        return 1;
                    else if (rol == "vendedor")
                        return 2;
                    else
                        throw new Exception("Rol no válido para este usuario.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al obtener ID del usuario: " + ex.Message);
                    return 0;
                }
            }
        }


        private void AgregarTransaccion(int idUsuario, int idSesion, int idAsiento, DateTime fechaHora, int totalAsientos, string tipoAsignacion, int idSala, string fila, int numero)
        {
            int idTransaccion;

            // Inserción en AsientoTransaccion
            string queryAsientoTransaccion = @"
        INSERT INTO AsientoTransaccion (id_usuario, id_sesion, fecha_hora, total_asientos, tipo_asignacion)
        OUTPUT INSERTED.id_transaccion  -- Captura el id_transaccion generado
        VALUES (@idUsuario, @idSesion, @fechaHora, @totalAsientos, @tipoAsignacion)";

            using (SqlCommand cmd = new SqlCommand(queryAsientoTransaccion, conn))
            {
                cmd.Parameters.AddWithValue("@idUsuario", idUsuario);
                cmd.Parameters.AddWithValue("@idSesion", idSesion);
                cmd.Parameters.AddWithValue("@fechaHora", fechaHora);
                cmd.Parameters.AddWithValue("@totalAsientos", totalAsientos);
                cmd.Parameters.AddWithValue("@tipoAsignacion", tipoAsignacion);

                conn.Open();
                idTransaccion = (int)cmd.ExecuteScalar();  // Guarda el id_transaccion recién creado
                conn.Close();
            }

            // Inserción en Transaccion
            string queryTransaccion = @"
        INSERT INTO Transaccion (id_asiento, id_transaccion, id_sesion, id_sala, fila, numero)
        VALUES (@idAsiento, @idTransaccion, @idSesion, @idSala, @fila, @numero)";

            using (SqlCommand cmd = new SqlCommand(queryTransaccion, conn))
            {
                cmd.Parameters.AddWithValue("@idAsiento", idAsiento);
                cmd.Parameters.AddWithValue("@idTransaccion", idTransaccion);
                cmd.Parameters.AddWithValue("@idSesion", idSesion);
                cmd.Parameters.AddWithValue("@idSala", idSala);
                cmd.Parameters.AddWithValue("@fila", fila);
                cmd.Parameters.AddWithValue("@numero", numero);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }




        private DataTable ObtenerAsientosDisponibles(int idSala, int idSesion)
        {
            string query = @"
        SELECT A.id_asiento, A.fila, A.numero
        FROM Asiento A
        WHERE A.id_sala = @idSala
        AND A.id_asiento NOT IN (
            SELECT T.id_asiento
            FROM Transaccion T
            WHERE T.id_sesion = @idSesion
        )";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@idSala", idSala);
                cmd.Parameters.AddWithValue("@idSesion", idSesion);
                DataTable dt = new DataTable();
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
                return dt;
            }
        }


        private Form CrearFormularioAsientoManualConAsientosDisponibles(DataTable asientosDisponibles)
        {
            Form inputForm = new Form
            {
                Text = "Seleccionar Asiento Manualmente",
                Size = new Size(300, 250),
                StartPosition = FormStartPosition.CenterParent
            };

            Label lblFila = new Label() { Left = 20, Top = 40, Text = "Fila:" };
            ComboBox cmbFila = new ComboBox() { Left = 150, Top = 30, Width = 100, Name = "cmbFila" };

            Label lblNumero = new Label() { Left = 20, Top = 80, Text = "Número:" };
            ComboBox cmbNumero = new ComboBox() { Left = 150, Top = 80, Width = 100, Name = "cmbNumero" };

            // Llenar el ComboBox con las filas únicas de asientos disponibles
            foreach (DataRow row in asientosDisponibles.Rows)
            {
                string fila = row["fila"].ToString();
                if (!cmbFila.Items.Contains(fila))
                    cmbFila.Items.Add(fila);
            }

            // Actualizar los números de asiento disponibles cuando se selecciona una fila
            cmbFila.SelectedIndexChanged += (s, e) =>
            {
                cmbNumero.Items.Clear();
                string selectedFila = cmbFila.SelectedItem.ToString();
                foreach (DataRow row in asientosDisponibles.Select($"fila = '{selectedFila}'"))
                {
                    int numero = (int)row["numero"];
                    cmbNumero.Items.Add(numero);
                }
                if (cmbNumero.Items.Count > 0)
                    cmbNumero.SelectedIndex = 0;
            };

            if (cmbFila.Items.Count > 0)
                cmbFila.SelectedIndex = 0;

            Button btnConfirmar = new Button() { Text = "Confirmar", Left = 100, Width = 100, Top = 140, DialogResult = DialogResult.OK };

            inputForm.Controls.Add(lblFila);
            inputForm.Controls.Add(cmbFila);
            inputForm.Controls.Add(lblNumero);
            inputForm.Controls.Add(cmbNumero);
            inputForm.Controls.Add(btnConfirmar);

            return inputForm;
        }



        private void AsignarAsientosManual(int idSesion, int idSala, int cantidadAsientos)
        {
            DataTable asientosDisponibles = ObtenerAsientosDisponibles(idSala, idSesion);
            int idUsuario = ObtenerIdUsuario();

            if (asientosDisponibles.Rows.Count < cantidadAsientos)
            {
                MessageBox.Show("No hay suficientes asientos disponibles para completar la compra.");
                return;
            }

            // Crear solo una entrada en AsientoTransaccion
            DateTime fechaHora = DateTime.Now; // Asignar la fecha y hora actual
            int idTransaccion = AgregarTransaccionAsiento(idUsuario, idSesion, fechaHora, cantidadAsientos, "manual");

            if (idTransaccion <= 0)
            {
                MessageBox.Show("Error al crear la transacción.");
                return;
            }

            int asientosAsignados = 0;
            for (int i = 0; i < cantidadAsientos; i++)
            {
                asientosDisponibles = ObtenerAsientosDisponibles(idSala, idSesion);

                if (asientosDisponibles.Rows.Count == 0)
                {
                    MessageBox.Show("La sesión se llenó mientras realizaba la selección. No hay asientos disponibles.");
                    return;
                }

                using (Form inputForm = CrearFormularioAsientoManualConAsientosDisponibles(asientosDisponibles))
                {
                    if (inputForm.ShowDialog() == DialogResult.OK)
                    {
                        string fila = inputForm.Controls["cmbFila"].Text;
                        int numero = int.Parse(((ComboBox)inputForm.Controls["cmbNumero"]).SelectedItem.ToString());

                        DataRow[] asientoSeleccionado = asientosDisponibles.Select($"fila = '{fila}' AND numero = {numero}");

                        if (asientoSeleccionado.Length > 0)
                        {
                            int idAsiento = Convert.ToInt32(asientoSeleccionado[0]["id_asiento"]);

                            // Registrar cada asiento individualmente en la tabla Transaccion
                            AgregarDetalleTransaccion(idAsiento, idTransaccion, idSesion, idSala, fila, numero);
                            asientosAsignados++;
                        }
                        else
                        {
                            MessageBox.Show($"El asiento Fila: {fila}, Número: {numero} ya no está disponible.");
                        }
                    }
                }
            }

            if (asientosAsignados > 0)
            {
                MessageBox.Show($"{asientosAsignados} asientos asignados correctamente.");
                LoadTransacciones();
                LoadAsientoTransaccion();
            }
            else
            {
                MessageBox.Show("No se pudieron asignar asientos manualmente.");
            }
        }



        private void AsignarAsientosAutomatica(int idSesion, int idSala, int cantidadAsientos)
        {
            DataTable asientosDisponibles = ObtenerAsientosDisponibles(idSala, idSesion);

            if (asientosDisponibles.Rows.Count < cantidadAsientos)
            {
                MessageBox.Show("No hay suficientes asientos disponibles para completar la compra.");
                return;
            }

            int idUsuario = ObtenerIdUsuario();
            DateTime fechaHora = DateTime.Now;  // Asignar la fecha y hora actual
            int idTransaccion;

            // Crear solo una entrada en AsientoTransaccion
            idTransaccion = AgregarTransaccionAsiento(idUsuario, idSesion, fechaHora, cantidadAsientos, "automatica");

            if (idTransaccion <= 0)
            {
                MessageBox.Show("Error al crear la transacción.");
                return;
            }

            // Asignar los asientos específicos a la transacción
            int asientosAsignados = 0;
            foreach (DataRow asiento in asientosDisponibles.Rows)
            {
                if (asientosAsignados >= cantidadAsientos)
                    break;

                int idAsiento = Convert.ToInt32(asiento["id_asiento"]);
                string fila = asiento["fila"].ToString();
                int numero = Convert.ToInt32(asiento["numero"]);

                // Registrar cada asiento individualmente en la tabla Transaccion
                AgregarDetalleTransaccion(idAsiento, idTransaccion, idSesion, idSala, fila, numero);
                asientosAsignados++;
            }

            if (asientosAsignados > 0)
            {
                MessageBox.Show($"{asientosAsignados} asientos asignados correctamente.");
                LoadTransacciones();
                LoadAsientoTransaccion();
            }
            else
            {
                MessageBox.Show("No se pudieron asignar asientos automáticamente.");
            }
        }

        // Función para agregar una sola entrada en AsientoTransaccion
        private int AgregarTransaccionAsiento(int idUsuario, int idSesion, DateTime fechaHora, int totalAsientos, string tipoAsignacion)
        {
            int idTransaccion;
            string query = @"
        INSERT INTO AsientoTransaccion (id_usuario, id_sesion, fecha_hora, total_asientos, tipo_asignacion)
        OUTPUT INSERTED.id_transaccion
        VALUES (@idUsuario, @idSesion, @fechaHora, @totalAsientos, @tipoAsignacion)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@idUsuario", idUsuario);
                cmd.Parameters.AddWithValue("@idSesion", idSesion);
                cmd.Parameters.AddWithValue("@fechaHora", fechaHora);
                cmd.Parameters.AddWithValue("@totalAsientos", totalAsientos);
                cmd.Parameters.AddWithValue("@tipoAsignacion", tipoAsignacion);

                conn.Open();
                idTransaccion = (int)cmd.ExecuteScalar();  // Guarda el id_transaccion recién creado
                conn.Close();
            }
            return idTransaccion;
        }

        // Función para agregar cada asiento individualmente en Transaccion
        private void AgregarDetalleTransaccion(int idAsiento, int idTransaccion, int idSesion, int idSala, string fila, int numero)
        {
            string query = @"
        INSERT INTO Transaccion (id_asiento, id_transaccion, id_sesion, id_sala, fila, numero)
        VALUES (@idAsiento, @idTransaccion, @idSesion, @idSala, @fila, @numero)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@idAsiento", idAsiento);
                cmd.Parameters.AddWithValue("@idTransaccion", idTransaccion);
                cmd.Parameters.AddWithValue("@idSesion", idSesion);
                cmd.Parameters.AddWithValue("@idSala", idSala);
                cmd.Parameters.AddWithValue("@fila", fila);
                cmd.Parameters.AddWithValue("@numero", numero);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }



        private int ObtenerIdAsiento(int idSala, string fila, int numero)
        {
            string query = "SELECT id_asiento FROM Asiento WHERE id_sala = @idSala AND fila = @fila AND numero = @numero";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@idSala", idSala);
                cmd.Parameters.AddWithValue("@fila", fila);
                cmd.Parameters.AddWithValue("@numero", numero);

                try
                {
                    conn.Open();
                    var result = cmd.ExecuteScalar();
                    conn.Close();

                    return result != null ? Convert.ToInt32(result) : 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al obtener el ID del asiento: {ex.Message}");
                    conn.Close();
                    return 0;
                }
            }
        }


        private void btnCambiarAsiento_Click(object sender, EventArgs e)
        {
            if (dataGridViewAsientos.SelectedRows.Count > 0)
            {
                // Obtener información de la sesión y del asiento actual
                int idSesion = (int)cmbSesiones.SelectedValue;
                int idSala = Convert.ToInt32(dataGridViewAsientos.SelectedRows[0].Cells["id_sala"].Value);
                int idAsientoActual = Convert.ToInt32(dataGridViewAsientos.SelectedRows[0].Cells["id_asiento"].Value);
                int idTransaccion = Convert.ToInt32(dataGridViewAsientos.SelectedRows[0].Cells["id_transaccion"].Value);
                string filaActual = dataGridViewAsientos.SelectedRows[0].Cells["fila"].Value.ToString();
                int numeroActual = Convert.ToInt32(dataGridViewAsientos.SelectedRows[0].Cells["numero"].Value);

                // Obtener la lista de asientos disponibles para la misma sala y sesión
                DataTable asientosDisponibles = ObtenerAsientosDisponibles(idSala, idSesion);

                if (asientosDisponibles.Rows.Count == 0)
                {
                    MessageBox.Show("No hay asientos disponibles para esta sala y sesión.");
                    return;
                }

                using (Form inputForm = CrearFormularioAsientoManualConAsientosDisponibles(asientosDisponibles))
                {
                    if (inputForm.ShowDialog() == DialogResult.OK)
                    {
                        string nuevaFila = inputForm.Controls["cmbFila"].Text;
                        int nuevoNumero = int.Parse(((ComboBox)inputForm.Controls["cmbNumero"]).SelectedItem.ToString());

                        // Verificar si el asiento seleccionado es el mismo que el actual
                        if (nuevaFila == filaActual && nuevoNumero == numeroActual)
                        {
                            MessageBox.Show("El asiento seleccionado es el mismo que el asiento actual. No se requiere cambio.");
                            return;
                        }

                        // Obtener el ID del nuevo asiento seleccionado
                        int idAsientoNuevo = ObtenerIdAsiento(idSala, nuevaFila, nuevoNumero);

                        if (idAsientoNuevo > 0)
                        {
                            // Actualizar el asiento en la tabla Transaccion
                            string updateQueryTransaccion = @"
                    UPDATE Transaccion
                    SET id_asiento = @idAsientoNuevo, fila = @nuevaFila, numero = @nuevoNumero
                    WHERE id_transaccion = @idTransaccion AND id_asiento = @idAsientoActual";

                            using (SqlCommand cmd = new SqlCommand(updateQueryTransaccion, conn))
                            {
                                cmd.Parameters.AddWithValue("@idAsientoNuevo", idAsientoNuevo);
                                cmd.Parameters.AddWithValue("@nuevaFila", nuevaFila);
                                cmd.Parameters.AddWithValue("@nuevoNumero", nuevoNumero);
                                cmd.Parameters.AddWithValue("@idTransaccion", idTransaccion);
                                cmd.Parameters.AddWithValue("@idAsientoActual", idAsientoActual);

                                conn.Open();
                                int rowsAffected = cmd.ExecuteNonQuery();
                                conn.Close();

                                if (rowsAffected > 0)
                                {
                                    // Registrar el cambio en AsientoTransaccion actualizando la fecha y el tipo de asignación
                                    string updateQueryAsientoTransaccion = @"
                            UPDATE AsientoTransaccion
                            SET fecha_hora = @fechaHora, tipo_asignacion = 'manual'
                            WHERE id_transaccion = @idTransaccion";

                                    using (SqlCommand cmd2 = new SqlCommand(updateQueryAsientoTransaccion, conn))
                                    {
                                        cmd2.Parameters.AddWithValue("@fechaHora", DateTime.Now);
                                        cmd2.Parameters.AddWithValue("@idTransaccion", idTransaccion);

                                        conn.Open();
                                        cmd2.ExecuteNonQuery();
                                        conn.Close();
                                    }

                                    MessageBox.Show("Asiento cambiado exitosamente.");

                                    // Recargar ambas tablas para reflejar el cambio de asiento
                                    LoadTransacciones();
                                    LoadAsientoTransaccion();
                                }
                                else
                                {
                                    MessageBox.Show("No se encontró el asiento actual en la transacción. Verifique que los datos son correctos.");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Error al obtener el ID del nuevo asiento. Verifique que el asiento seleccionado esté disponible.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un asiento para cambiar.");
            }
        }

        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu(rolUsuario, nombreUsuario);
            this.Close();
        }
    }
}
