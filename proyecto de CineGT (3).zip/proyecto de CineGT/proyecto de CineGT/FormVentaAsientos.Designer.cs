﻿namespace proyecto_de_CineGT
{
    partial class FormVentaAsientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSesiones = new System.Windows.Forms.ComboBox();
            this.numericUpDownCantidadAsientos = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButtonAutomatico = new System.Windows.Forms.RadioButton();
            this.btnVenderAsientos = new System.Windows.Forms.Button();
            this.dataGridViewAsientos = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButtonManual = new System.Windows.Forms.RadioButton();
            this.btnCambiarAsiento = new System.Windows.Forms.Button();
            this.dataGridViewTransacciones = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnVolverMenu = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantidadAsientos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAsientos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransacciones)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbSesiones
            // 
            this.cmbSesiones.FormattingEnabled = true;
            this.cmbSesiones.Location = new System.Drawing.Point(296, 173);
            this.cmbSesiones.Name = "cmbSesiones";
            this.cmbSesiones.Size = new System.Drawing.Size(453, 24);
            this.cmbSesiones.TabIndex = 0;
            // 
            // numericUpDownCantidadAsientos
            // 
            this.numericUpDownCantidadAsientos.Location = new System.Drawing.Point(296, 230);
            this.numericUpDownCantidadAsientos.Name = "numericUpDownCantidadAsientos";
            this.numericUpDownCantidadAsientos.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownCantidadAsientos.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "ingrese cantidad de asientos";
            // 
            // radioButtonAutomatico
            // 
            this.radioButtonAutomatico.AutoSize = true;
            this.radioButtonAutomatico.Location = new System.Drawing.Point(296, 276);
            this.radioButtonAutomatico.Name = "radioButtonAutomatico";
            this.radioButtonAutomatico.Size = new System.Drawing.Size(163, 20);
            this.radioButtonAutomatico.TabIndex = 3;
            this.radioButtonAutomatico.TabStop = true;
            this.radioButtonAutomatico.Text = "asignacion automatica";
            this.radioButtonAutomatico.UseVisualStyleBackColor = true;
            // 
            // btnVenderAsientos
            // 
            this.btnVenderAsientos.Location = new System.Drawing.Point(306, 349);
            this.btnVenderAsientos.Name = "btnVenderAsientos";
            this.btnVenderAsientos.Size = new System.Drawing.Size(131, 36);
            this.btnVenderAsientos.TabIndex = 4;
            this.btnVenderAsientos.Text = "confirmar compra";
            this.btnVenderAsientos.UseVisualStyleBackColor = true;
            this.btnVenderAsientos.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridViewAsientos
            // 
            this.dataGridViewAsientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAsientos.Location = new System.Drawing.Point(68, 410);
            this.dataGridViewAsientos.Name = "dataGridViewAsientos";
            this.dataGridViewAsientos.RowHeadersWidth = 51;
            this.dataGridViewAsientos.RowTemplate.Height = 24;
            this.dataGridViewAsientos.Size = new System.Drawing.Size(1038, 227);
            this.dataGridViewAsientos.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "sesiones";
            // 
            // radioButtonManual
            // 
            this.radioButtonManual.AutoSize = true;
            this.radioButtonManual.Location = new System.Drawing.Point(296, 308);
            this.radioButtonManual.Name = "radioButtonManual";
            this.radioButtonManual.Size = new System.Drawing.Size(141, 20);
            this.radioButtonManual.TabIndex = 7;
            this.radioButtonManual.TabStop = true;
            this.radioButtonManual.Text = "asignacion manual";
            this.radioButtonManual.UseVisualStyleBackColor = true;
            // 
            // btnCambiarAsiento
            // 
            this.btnCambiarAsiento.Location = new System.Drawing.Point(853, 349);
            this.btnCambiarAsiento.Name = "btnCambiarAsiento";
            this.btnCambiarAsiento.Size = new System.Drawing.Size(131, 36);
            this.btnCambiarAsiento.TabIndex = 8;
            this.btnCambiarAsiento.Text = "cambiar asiento";
            this.btnCambiarAsiento.UseVisualStyleBackColor = true;
            this.btnCambiarAsiento.Click += new System.EventHandler(this.btnCambiarAsiento_Click);
            // 
            // dataGridViewTransacciones
            // 
            this.dataGridViewTransacciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTransacciones.Location = new System.Drawing.Point(71, 679);
            this.dataGridViewTransacciones.Name = "dataGridViewTransacciones";
            this.dataGridViewTransacciones.RowHeadersWidth = 51;
            this.dataGridViewTransacciones.RowTemplate.Height = 24;
            this.dataGridViewTransacciones.Size = new System.Drawing.Size(1035, 210);
            this.dataGridViewTransacciones.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 391);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "tabla transaccion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 660);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "tabla asiento transaccion";
            // 
            // btnVolverMenu
            // 
            this.btnVolverMenu.Location = new System.Drawing.Point(1020, 12);
            this.btnVolverMenu.Name = "btnVolverMenu";
            this.btnVolverMenu.Size = new System.Drawing.Size(111, 39);
            this.btnVolverMenu.TabIndex = 12;
            this.btnVolverMenu.Text = "volver al menu";
            this.btnVolverMenu.UseVisualStyleBackColor = true;
            this.btnVolverMenu.Click += new System.EventHandler(this.btnVolverMenu_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(721, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(368, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "seleccione una fila de tabla transaccion que desea modificar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 25.8F);
            this.label6.Location = new System.Drawing.Point(248, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(688, 45);
            this.label6.TabIndex = 14;
            this.label6.Text = "VENTA Y CAMBIO DE ASIENTOS";
            // 
            // FormVentaAsientos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1143, 989);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnVolverMenu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridViewTransacciones);
            this.Controls.Add(this.btnCambiarAsiento);
            this.Controls.Add(this.radioButtonManual);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridViewAsientos);
            this.Controls.Add(this.btnVenderAsientos);
            this.Controls.Add(this.radioButtonAutomatico);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDownCantidadAsientos);
            this.Controls.Add(this.cmbSesiones);
            this.Name = "FormVentaAsientos";
            this.Text = "FormVentaAsientos";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantidadAsientos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAsientos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransacciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSesiones;
        private System.Windows.Forms.NumericUpDown numericUpDownCantidadAsientos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButtonAutomatico;
        private System.Windows.Forms.Button btnVenderAsientos;
        private System.Windows.Forms.DataGridView dataGridViewAsientos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButtonManual;
        private System.Windows.Forms.Button btnCambiarAsiento;
        private System.Windows.Forms.DataGridView dataGridViewTransacciones;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnVolverMenu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}