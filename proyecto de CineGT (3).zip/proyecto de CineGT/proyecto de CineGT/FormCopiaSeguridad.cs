﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto_de_CineGT
{
    public partial class FormCopiaSeguridad : Form
    {
        private string rolUsuario;
        private string nombreUsuario;
        private SqlConnection conn;

        public FormCopiaSeguridad()
        {
            InitializeComponent();
            conn = GetConnection();

        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(ConfigurationManager.ConnectionStrings["CineDB"].ConnectionString);
        }
        private void btnVolverMenu_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu(rolUsuario, nombreUsuario);
            this.Close();
        }
    }
}
